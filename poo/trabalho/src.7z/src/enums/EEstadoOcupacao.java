package enums;

public enum EEstadoOcupacao {
	DISPONIVEL, OCUPADO, MANUTENCAO
}
